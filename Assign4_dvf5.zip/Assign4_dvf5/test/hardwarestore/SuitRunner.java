package hardwarestore;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class) @Suite.SuiteClasses({TestHardwareInventory.class,TestInputs.class})
public class SuitRunner {
// the class remains empty,
// used only as a holder for the above annotations
}



import java.util.*;

/**
 * 
 */
public class Website {

    /**
     * Default constructor
     */
    public Website() {
    }

    /**
     * 
     */
    private String username;

    /**
     * 
     */
    private String password;

    /**
     * 
     */
    public User 1..*;

    /**
     * 
     */
    public TransactionManagement 1;

    /**
     * 
     */
    public InventoryManagement 1;


    /**
     * @return
     */
    public String getUsername() {
        // TODO implement here
        return "";
    }

    /**
     * @param value
     */
    public void setUsername(String value) {
        // TODO implement here
    }

    /**
     * @return
     */
    public String getPassword() {
        // TODO implement here
        return "";
    }

    /**
     * @param value
     */
    public void setPassword(String value) {
        // TODO implement here
    }

    /**
     * 
     */
    public void editInfo() {
        // TODO implement here
    }

    /**
     * 
     */
    public void logIn() {
        // TODO implement here
    }

    /**
     * 
     */
    public void logOut() {
        // TODO implement here
    }

    /**
     * 
     */
    public void MessageEmployee() {
        // TODO implement here
    }

    /**
     * 
     */
    public void placeOrder() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Operation1() {
        // TODO implement here
    }

}
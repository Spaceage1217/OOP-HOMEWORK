
import java.util.*;

/**
 * 
 */
public class User {

    /**
     * Default constructor
     */
    public User() {
    }

    /**
     * 
     */
    private Int ID;

    /**
     * 
     */
    private String FirstName;

    /**
     * 
     */
    private String lastName;



    /**
     * 
     */
    public TransactionManagement 1;

    /**
     * 
     */
    public AccountingManagement 1;


    /**
     * @return
     */
    public Int getID() {
        // TODO implement here
        return null;
    }

    /**
     * @param value
     */
    public void setID(Int value) {
        // TODO implement here
    }

    /**
     * @return
     */
    public String getFirstName() {
        // TODO implement here
        return "";
    }

    /**
     * @param value
     */
    public void setFirstName(String value) {
        // TODO implement here
    }

    /**
     * @return
     */
    public String getLastName() {
        // TODO implement here
        return "";
    }

    /**
     * @param value
     */
    public void setLastName(String value) {
        // TODO implement here
    }

}

import java.util.*;

/**
 * 
 */
public class SmallHardwareItem extends Item {

    /**
     * Default constructor
     */
    public SmallHardwareItem() {
    }

    /**
     * 
     */
    private String category;

    /**
     * @return
     */
    public String getCategory() {
        // TODO implement here
        return "";
    }

    /**
     * @param value
     */
    public void setCategory(String value) {
        // TODO implement here
    }

}
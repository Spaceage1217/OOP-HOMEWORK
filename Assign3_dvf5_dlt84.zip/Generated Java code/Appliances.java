
import java.util.*;

/**
 * 
 */
public class Appliances extends Item {

    /**
     * Default constructor
     */
    public Appliances() {
    }

    /**
     * 
     */
    private String brand;

    /**
     * 
     */
    private String type;

    /**
     * @return
     */
    public String getBrand() {
        // TODO implement here
        return "";
    }

    /**
     * @param value
     */
    public void setBrand(String value) {
        // TODO implement here
    }

    /**
     * @return
     */
    public String getType() {
        // TODO implement here
        return "";
    }

    /**
     * @param value
     */
    public void setType(String value) {
        // TODO implement here
    }

}
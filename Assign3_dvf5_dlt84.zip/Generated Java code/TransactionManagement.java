
import java.util.*;

/**
 * 
 */
public class TransactionManagement {

    /**
     * Default constructor
     */
    public TransactionManagement() {
    }

    /**
     * 
     */
    private String TransactionDB;


    /**
     * 
     */
    public Item 1..*;


    /**
     * 
     */
    public User 1..*;

    /**
     * 
     */
    public Website 1;

    /**
     * 
     */
    public void DisplayTransactions() {
        // TODO implement here
    }

    /**
     * 
     */
    public void SearchTransactions() {
        // TODO implement here
    }

    /**
     * 
     */
    public void addNewTransaction() {
        // TODO implement here
    }

    /**
     * @return
     */
    public String getTransactionDB() {
        // TODO implement here
        return "";
    }

    /**
     * @param value
     */
    public void setTransactionDB(String value) {
        // TODO implement here
    }

}
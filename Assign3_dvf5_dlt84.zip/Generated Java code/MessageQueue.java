
import java.util.*;

/**
 * 
 */
public class MessageQueue {

    /**
     * Default constructor
     */
    public MessageQueue() {
    }

    /**
     * 
     */
    public String message;

    /**
     * 
     */
    public Website 1;

    /**
     * 
     */
    public void readMessage() {
        // TODO implement here
    }

    /**
     * 
     */
    public void displayMessages() {
        // TODO implement here
    }

    /**
     * 
     */
    public void reply() {
        // TODO implement here
    }

}

import java.util.*;

/**
 * 
 */
public class AccountingManagement {

    /**
     * Default constructor
     */
    public AccountingManagement() {
    }

    /**
     * 
     */
    private String AccountingDB;




    /**
     * 
     */
    public void getEmployeeExpense() {
        // TODO implement here
    }

    /**
     * 
     */
    public void getHardwareStoreProfit() {
        // TODO implement here
    }

    /**
     * 
     */
    public void printFinancialDoc() {
        // TODO implement here
    }

    /**
     * 
     */
    public void displayReport() {
        // TODO implement here
    }

    /**
     * @return
     */
    public String getAccountingDB() {
        // TODO implement here
        return "";
    }

    /**
     * @param value
     */
    public void setAccountingDB(String value) {
        // TODO implement here
    }

}
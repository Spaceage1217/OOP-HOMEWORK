
import java.util.*;

/**
 * 
 */
public class Customer extends User {

    /**
     * Default constructor
     */
    public Customer() {
    }

    /**
     * 
     */
    private String phoneNumber;

    /**
     * 
     */
    private String address;

    /**
     * @return
     */
    public String getPhoneNumber() {
        // TODO implement here
        return "";
    }

    /**
     * @param value
     */
    public void setPhoneNumber(String value) {
        // TODO implement here
    }

    /**
     * @return
     */
    public String getAddress() {
        // TODO implement here
        return "";
    }

    /**
     * @param value
     */
    public void setAddress(String value) {
        // TODO implement here
    }

}
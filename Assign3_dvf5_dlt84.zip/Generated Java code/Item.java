
import java.util.*;

/**
 * 
 */
public class Item {

    /**
     * Default constructor
     */
    public Item() {
    }

    /**
     * 
     */
    private String ID;

    /**
     * 
     */
    private String ItemName;

    /**
     * 
     */
    private int quantity;

    /**
     * 
     */
    private float price;



    /**
     * @return
     */
    public String getID() {
        // TODO implement here
        return "";
    }

    /**
     * @param value
     */
    public void setID(String value) {
        // TODO implement here
    }

    /**
     * @return
     */
    public String getItemName() {
        // TODO implement here
        return "";
    }

    /**
     * @param value
     */
    public void setItemName(String value) {
        // TODO implement here
    }

    /**
     * @return
     */
    public int getQuantity() {
        // TODO implement here
        return 0;
    }

    /**
     * @param value
     */
    public void setQuantity(int value) {
        // TODO implement here
    }

    /**
     * @return
     */
    public float getPrice() {
        // TODO implement here
        return 0.0f;
    }

    /**
     * @param value
     */
    public void setPrice(float value) {
        // TODO implement here
    }

}
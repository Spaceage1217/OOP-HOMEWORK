
import java.util.*;

/**
 * 
 */
public class InventoryManagement {

    /**
     * Default constructor
     */
    public InventoryManagement() {
    }

    /**
     * 
     */
    private String InventoryDB;

    /**
     * 
     */
    public Item 1..*;


    /**
     * 
     */
    public Website 1;

    /**
     * @return
     */
    public void DisplayInventory() {
        // TODO implement here
        return null;
    }

    /**
     * 
     */
    public void Search() {
        // TODO implement here
    }

    /**
     * 
     */
    public void delete() {
        // TODO implement here
    }

    /**
     * 
     */
    public void addNewItem() {
        // TODO implement here
    }

    /**
     * 
     */
    public void editItems() {
        // TODO implement here
    }

    /**
     * @return
     */
    public String getInventoryDB() {
        // TODO implement here
        return "";
    }

    /**
     * @param value
     */
    public void setInventoryDB(String value) {
        // TODO implement here
    }

}
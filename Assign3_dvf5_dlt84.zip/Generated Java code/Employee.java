
import java.util.*;

/**
 * 
 */
public class Employee extends User {

    /**
     * Default constructor
     */
    public Employee() {
    }

    /**
     * 
     */
    private Int SSN;

    /**
     * 
     */
    private float Salary;

    /**
     * 
     */
    private String Status;

    /**
     * 
     */
    private String Type;


    /**
     * @return
     */
    public int getSSN() {
        // TODO implement here
        return 0;
    }

    /**
     * @return
     */
    public int setSSN() {
        // TODO implement here
        return 0;
    }

    /**
     * @return
     */
    public float getSalary() {
        // TODO implement here
        return 0.0f;
    }

    /**
     * @param value
     */
    public void setSalary(float value) {
        // TODO implement here
    }

    /**
     * @return
     */
    public String getStatus() {
        // TODO implement here
        return "";
    }

    /**
     * @param value
     */
    public void setStatus(String value) {
        // TODO implement here
    }

    /**
     * @return
     */
    public String getType() {
        // TODO implement here
        return "";
    }

    /**
     * @param value
     */
    public void setType(String value) {
        // TODO implement here
    }

}